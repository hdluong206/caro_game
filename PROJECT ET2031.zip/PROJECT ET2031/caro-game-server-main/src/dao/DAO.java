package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Admin
 */
public class DAO {
    protected Connection con;
    private static final Logger LOGGER = Logger.getLogger(DAO.class.getName());

    public DAO() {
        final String DATABASE_NAME = "caro_game"; // Database name
        final String jdbcURL = "jdbc:mysql://localhost:3306/caro_game?useSSL=false";
        final String JDBC_USER = System.getenv("DB_USER");  // Read from environment variables
        final String JDBC_PASSWORD = System.getenv("DB_PASSWORD"); // Read from environment variables

        if (JDBC_USER == null || JDBC_PASSWORD == null) {
            LOGGER.severe("Database credentials not set in environment variables");
            return;
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(jdbcURL, JDBC_USER, JDBC_PASSWORD);
            LOGGER.info("Connection to database successful");
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Connection to database failed", e);
        }
    }
}
